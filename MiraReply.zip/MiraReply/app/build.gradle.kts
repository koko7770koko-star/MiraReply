plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.mirareply"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.example.mirareply"
        minSdk = 31          // Android 12 以上
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"
        ndk { abiFilters += listOf("arm64-v8a") }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // 自分の端末で使う前提なので debug 署名でそのまま入れられるようにしておく
            signingConfig = signingConfigs.getByName("debug")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    packaging {
        jniLibs { useLegacyPackaging = true }
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
        // LiteRT-LM は新しい Kotlin でビルドされているため（Google AI Edge Gallery と同じ対処）
        freeCompilerArgs.add("-Xskip-metadata-version-check")
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")
    // 端末内でLLMを動かすGoogle公式ランタイム（Google AI Edge Gallery と同じ版）
    implementation("com.google.ai.edge.litertlm:litertlm-android:0.18.0")
}
