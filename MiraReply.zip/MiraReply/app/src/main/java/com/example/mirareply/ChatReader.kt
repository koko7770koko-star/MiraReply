package com.example.mirareply

import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo

data class ChatMessage(val text: String, val fromUser: Boolean, val top: Int)

data class ChatScreen(
    val messages: List<ChatMessage>,
    val input: AccessibilityNodeInfo?,
)

/**
 * 画面のアクセシビリティ情報からチャットの吹き出しを読み取る。
 * MiraiMind の内部構造は公開されていないため、
 *   ・一番大きいスクロール領域 = メッセージ一覧
 *   ・吹き出しが右寄り = 自分、左寄り = キャラクター
 * という見た目の位置で判定する。うまくいかない場合は設定画面で View ID を指定する。
 */
class ChatReader(private val prefs: Prefs) {

    fun read(root: AccessibilityNodeInfo, screenWidth: Int): ChatScreen {
        val input = findInput(root)
        val list = findMessageList(root)
        val listRect = Rect().also { (list ?: root).getBoundsInScreen(it) }
        val inputTop = input?.let { Rect().also { r -> it.getBoundsInScreen(r) }.top } ?: Int.MAX_VALUE

        val texts = ArrayList<Pair<String, Rect>>()
        collectTexts(list ?: root, texts, depth = 0)

        val msgs = texts
            .filter { (_, r) -> r.top >= listRect.top && r.bottom <= minOf(listRect.bottom, inputTop) + 4 }
            .filter { (t, _) -> !isNoise(t) }
            .map { (t, r) ->
                val leftGap = r.left - listRect.left
                val rightGap = listRect.right - r.right
                // 右側の余白が左側よりはっきり小さい → 自分の吹き出し
                val fromUser = rightGap + screenWidth * 0.05 < leftGap
                ChatMessage(t.trim(), fromUser, r.top)
            }
            .sortedBy { it.top }

        return ChatScreen(mergeAdjacent(msgs), input)
    }

    /** 同じ側に連続する短い断片（1つの吹き出しが複数のTextViewに分かれている場合）をまとめる */
    private fun mergeAdjacent(msgs: List<ChatMessage>): List<ChatMessage> {
        val out = ArrayList<ChatMessage>()
        for (m in msgs) {
            val last = out.lastOrNull()
            if (last != null && last.fromUser == m.fromUser && m.top - last.top < 40) {
                out[out.size - 1] = last.copy(text = last.text + "\n" + m.text)
            } else out.add(m)
        }
        return out
    }

    private fun collectTexts(node: AccessibilityNodeInfo, out: MutableList<Pair<String, Rect>>, depth: Int) {
        if (depth > 40) return
        if (!node.isVisibleToUser) return
        if (node.isEditable) return
        val cls = node.className?.toString() ?: ""
        // ボタン類は吹き出しではない
        val isButtonLike = cls.endsWith("Button") || cls.endsWith("ImageView")
        val text = node.text?.toString()
        if (!isButtonLike && !text.isNullOrBlank()) {
            val r = Rect(); node.getBoundsInScreen(r)
            if (r.width() > 0 && r.height() > 0) out.add(text to r)
        }
        for (i in 0 until node.childCount) {
            val c = node.getChild(i) ?: continue
            collectTexts(c, out, depth + 1)
        }
    }

    private val timeRegex = Regex("""^\s*(\d{1,2}[:：]\d{2}|\d{1,2}/\d{1,2}.*|昨日.*|今日.*|午前.*|午後.*)\s*$""")

    private fun isNoise(t: String): Boolean {
        val s = t.trim()
        if (s.isEmpty()) return true
        if (timeRegex.matches(s)) return true
        // 既読表示やUIラベルなど
        if (s in setOf("既読", "送信", "Send", "…", "...")) return true
        return false
    }

    fun findInput(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (prefs.inputViewId.isNotBlank()) {
            root.findAccessibilityNodeInfosByViewId(prefs.inputViewId).firstOrNull()?.let { return it }
        }
        return findFirst(root) { it.isEditable && it.isVisibleToUser }
    }

    private fun findMessageList(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (prefs.listViewId.isNotBlank()) {
            root.findAccessibilityNodeInfosByViewId(prefs.listViewId).firstOrNull()?.let { return it }
        }
        var best: AccessibilityNodeInfo? = null
        var bestArea = 0
        walk(root) { n ->
            val cls = n.className?.toString() ?: ""
            if (n.isScrollable || cls.contains("RecyclerView") || cls.contains("ListView")) {
                val r = Rect(); n.getBoundsInScreen(r)
                val area = r.width() * r.height()
                if (area > bestArea) { bestArea = area; best = n }
            }
        }
        return best
    }

    /** 送信ボタンを探す（ID指定 → 文字/説明に「送信」 → 入力欄の右側のクリック可能な要素） */
    fun findSendButton(root: AccessibilityNodeInfo, input: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (prefs.sendButtonId.isNotBlank()) {
            root.findAccessibilityNodeInfosByViewId(prefs.sendButtonId).firstOrNull()?.let { return clickableSelfOrParent(it) }
        }
        val words = listOf("送信", "send", "Send", "SEND")
        findFirst(root) { n ->
            n.isVisibleToUser && (n.isClickable || n.parent?.isClickable == true) &&
                words.any { w -> n.contentDescription?.contains(w) == true || n.text?.toString() == w }
        }?.let { return clickableSelfOrParent(it) }

        if (input == null) return null
        val inRect = Rect(); input.getBoundsInScreen(inRect)
        var best: AccessibilityNodeInfo? = null
        var bestDist = Int.MAX_VALUE
        walk(root) { n ->
            if (!n.isClickable || !n.isVisibleToUser || n.isEditable) return@walk
            val r = Rect(); n.getBoundsInScreen(r)
            val sameRow = r.centerY() in (inRect.top - 30)..(inRect.bottom + 30)
            if (sameRow && r.left >= inRect.right - 10) {
                val d = r.left - inRect.right
                if (d < bestDist) { bestDist = d; best = n }
            }
        }
        return best
    }

    private fun clickableSelfOrParent(n: AccessibilityNodeInfo): AccessibilityNodeInfo {
        var cur: AccessibilityNodeInfo? = n
        var i = 0
        while (cur != null && i < 4) {
            if (cur.isClickable) return cur
            cur = cur.parent; i++
        }
        return n
    }

    companion object {
        fun walk(node: AccessibilityNodeInfo, depth: Int = 0, f: (AccessibilityNodeInfo) -> Unit) {
            if (depth > 40) return
            f(node)
            for (i in 0 until node.childCount) {
                val c = node.getChild(i) ?: continue
                walk(c, depth + 1, f)
            }
        }

        fun findFirst(node: AccessibilityNodeInfo, pred: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
            var found: AccessibilityNodeInfo? = null
            walk(node) { if (found == null && pred(it)) found = it }
            return found
        }

        /** 調整用：画面構造をテキストに書き出す */
        fun dump(root: AccessibilityNodeInfo): String {
            val sb = StringBuilder()
            fun rec(n: AccessibilityNodeInfo, d: Int) {
                if (d > 40) return
                val r = Rect(); n.getBoundsInScreen(r)
                sb.append("  ".repeat(d))
                    .append(n.className?.toString()?.substringAfterLast('.'))
                    .append(" id=").append(n.viewIdResourceName ?: "-")
                    .append(" [").append(r.left).append(',').append(r.top).append(',').append(r.right).append(',').append(r.bottom).append(']')
                if (n.isClickable) sb.append(" clickable")
                if (n.isEditable) sb.append(" editable")
                if (n.isScrollable) sb.append(" scrollable")
                n.text?.let { sb.append(" text=\"").append(it.toString().replace("\n", "\\n").take(80)).append('"') }
                n.contentDescription?.let { sb.append(" desc=\"").append(it.toString().take(40)).append('"') }
                sb.append('\n')
                for (i in 0 until n.childCount) n.getChild(i)?.let { rec(it, d + 1) }
            }
            rec(root, 0)
            return sb.toString()
        }
    }
}
