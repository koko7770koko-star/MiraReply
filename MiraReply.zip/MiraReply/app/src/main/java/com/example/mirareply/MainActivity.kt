package com.example.mirareply

import android.app.Activity
import android.app.DownloadManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.util.TypedValue
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.io.File

/** 設定画面：モデルの準備、ユーザー補助の有効化、各種設定 */
class MainActivity : Activity() {

    private lateinit var prefs: Prefs
    private val main = Handler(Looper.getMainLooper())

    private lateinit var serviceStatus: TextView
    private lateinit var modelStatus: TextView
    private lateinit var modelGroup: RadioGroup
    private lateinit var autoSendSw: Switch
    private lateinit var delayEt: EditText
    private lateinit var styleEt: EditText
    private lateinit var ctxEt: EditText
    private lateinit var gpuSw: Switch
    private lateinit var pkgEt: EditText
    private lateinit var inputIdEt: EditText
    private lateinit var sendIdEt: EditText
    private lateinit var listIdEt: EditText

    private var downloadId = -1L
    private var copying = false

    private fun dp(v: Int) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        downloadId = getSharedPreferences("dl", MODE_PRIVATE).getLong("id", -1L)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(32))
        }
        setContentView(ScrollView(this).apply { fitsSystemWindows = true; addView(col) })

        col.addView(header("ミラ返信アシスト", 22f))
        col.addView(note("MiraiMindのチャット画面に返信候補を3つ表示します。AIはこのスマホの中だけで動き、会話内容は外部に送信されません。"))

        // ① モデル
        col.addView(header("① AIモデルを用意する"))
        modelGroup = RadioGroup(this)
        Prefs.MODELS.forEachIndexed { i, m ->
            modelGroup.addView(RadioButton(this).apply {
                id = 1000 + i; text = m.label; isChecked = prefs.modelId == m.id
            })
        }
        modelGroup.setOnCheckedChangeListener { _, checkedId ->
            prefs.modelId = Prefs.MODELS[checkedId - 1000].id
            refresh()
            ReplyAccessibilityService.instance?.reloadSettings(reloadModel = true)
        }
        col.addView(modelGroup)
        modelStatus = note("")
        col.addView(modelStatus)
        col.addView(button("モデルをダウンロード（Wi-Fi推奨）") { startDownload() })
        col.addView(button("ダウンロード済みのファイルを選ぶ（.litertlm）") { pickFile() })

        // ② ユーザー補助
        col.addView(header("② ユーザー補助（アクセシビリティ）をオンにする"))
        serviceStatus = note("")
        col.addView(serviceStatus)
        col.addView(button("ユーザー補助の設定を開く") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        col.addView(note("「制限付き設定」と出てオンにできない場合：下のボタン → 右上の︙ →「制限付き設定を許可」を押してから、もう一度オンにしてください。"))
        col.addView(button("このアプリの情報を開く") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        })

        // ③ 設定
        col.addView(header("③ 返信の設定"))
        autoSendSw = Switch(this).apply { text = "候補1を自動で送信する"; isChecked = prefs.autoSend }
        col.addView(autoSendSw)
        delayEt = field(col, "自動送信までの秒数", prefs.autoSendDelaySec.toString(), number = true)
        styleEt = field(col, "返信の雰囲気・自分の設定（AIへの指示）", prefs.styleHint, multi = true)
        ctxEt = field(col, "AIに読ませる直近のメッセージ数", prefs.contextCount.toString(), number = true)
        gpuSw = Switch(this).apply { text = "GPUを使う（速い。動かない時はオフ）"; isChecked = prefs.useGpu }
        col.addView(gpuSw)

        col.addView(header("詳細設定（うまく読み取れない時だけ）", 15f))
        pkgEt = field(col, "対象アプリのパッケージ名", prefs.targetPackage)
        listIdEt = field(col, "メッセージ一覧のView ID（空欄=自動）", prefs.listViewId)
        inputIdEt = field(col, "入力欄のView ID（空欄=自動）", prefs.inputViewId)
        sendIdEt = field(col, "送信ボタンのView ID（空欄=自動）", prefs.sendButtonId)
        col.addView(note("チャット画面で丸い「返」ボタン →「画面構造」を押すと画面の構造が保存されます。下のボタンで共有して中身を見ると、正しいIDがわかります。"))
        col.addView(button("保存した画面構造を共有") { shareDump() })

        col.addView(button("設定を保存") { save() })
    }

    override fun onResume() {
        super.onResume()
        refresh()
        pollDownload()
    }

    override fun onPause() {
        super.onPause()
        main.removeCallbacksAndMessages(null)
    }

    private fun refresh() {
        val enabled = isServiceEnabled()
        serviceStatus.text = if (enabled) "状態：オン ✅" else "状態：オフ（「ミラ返信アシスト」をオンにしてください）"
        serviceStatus.setTextColor(if (enabled) Color.parseColor("#2E7D32") else Color.parseColor("#C62828"))
        if (!copying) {
            val f = prefs.modelFile()
            val m = prefs.model
            modelStatus.text = when {
                f.exists() && f.length() >= m.sizeBytes * 0.98 -> "モデル：準備済み ✅（${mb(f.length())}）"
                f.exists() -> "モデル：途中（${mb(f.length())} / ${mb(m.sizeBytes)}）"
                else -> "モデル：未ダウンロード"
            }
        }
    }

    private fun isServiceEnabled(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val me = ComponentName(this, ReplyAccessibilityService::class.java)
        return enabled.split(':').any { ComponentName.unflattenFromString(it) == me }
    }

    // ---------- モデルのダウンロード ----------

    private fun startDownload() {
        val m = prefs.model
        if (m.needsLogin) {
            // 利用規約への同意が必要なモデルはブラウザで落としてもらう
            toast("Hugging Faceにログインして規約に同意後ダウンロードし、「ファイルを選ぶ」で指定してください")
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(m.pageUrl)))
            return
        }
        val f = prefs.modelFile()
        if (f.exists()) f.delete()
        val req = DownloadManager.Request(Uri.parse(m.url))
            .setTitle("AIモデル ${m.fileName}")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalFilesDir(this, null, m.fileName)
            .setAllowedOverMetered(true)
        val dm = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
        downloadId = dm.enqueue(req)
        getSharedPreferences("dl", MODE_PRIVATE).edit().putLong("id", downloadId).apply()
        toast("ダウンロードを開始しました")
        pollDownload()
    }

    private fun pollDownload() {
        if (downloadId < 0) return
        val dm = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
        dm.query(DownloadManager.Query().setFilterById(downloadId))?.use { c ->
            if (!c.moveToFirst()) return
            val status = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
            val done = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
            val total = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
            when (status) {
                DownloadManager.STATUS_SUCCESSFUL -> {
                    downloadId = -1
                    getSharedPreferences("dl", MODE_PRIVATE).edit().remove("id").apply()
                    refresh()
                    ReplyAccessibilityService.instance?.reloadSettings(reloadModel = true)
                    return
                }
                DownloadManager.STATUS_FAILED -> {
                    downloadId = -1
                    modelStatus.text = "ダウンロード失敗。もう一度お試しください"
                    return
                }
                else -> {
                    val pct = if (total > 0) done * 100 / total else 0
                    modelStatus.text = "ダウンロード中… $pct%（${mb(done)} / ${mb(if (total > 0) total else prefs.model.sizeBytes)}）"
                }
            }
        }
        main.postDelayed({ pollDownload() }, 1000)
    }

    // ---------- ファイルから選ぶ ----------

    @Deprecated("Activity#onActivityResult")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_PICK && resultCode == RESULT_OK) data?.data?.let { copyModel(it) }
    }

    private fun pickFile() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
        }, REQ_PICK)
    }

    private fun copyModel(uri: Uri) {
        val dest = prefs.modelFile()
        copying = true
        Thread {
            try {
                val tmp = File(dest.path + ".part")
                contentResolver.openInputStream(uri)!!.use { input ->
                    tmp.outputStream().use { out ->
                        val buf = ByteArray(1 shl 20)
                        var total = 0L; var lastUi = 0L
                        while (true) {
                            val n = input.read(buf); if (n < 0) break
                            out.write(buf, 0, n); total += n
                            if (total - lastUi > (50L shl 20)) {
                                lastUi = total
                                val t = total
                                runOnUiThread { modelStatus.text = "コピー中… ${mb(t)}" }
                            }
                        }
                    }
                }
                dest.delete(); tmp.renameTo(dest)
                runOnUiThread {
                    copying = false; refresh()
                    ReplyAccessibilityService.instance?.reloadSettings(reloadModel = true)
                }
            } catch (t: Throwable) {
                runOnUiThread { copying = false; modelStatus.text = "コピー失敗: ${t.message}" }
            }
        }.start()
    }

    // ---------- 設定 ----------

    private fun save() {
        val gpuChanged = prefs.useGpu != gpuSw.isChecked
        prefs.autoSend = autoSendSw.isChecked
        prefs.autoSendDelaySec = delayEt.text.toString().toIntOrNull() ?: 5
        prefs.styleHint = styleEt.text.toString()
        prefs.contextCount = ctxEt.text.toString().toIntOrNull() ?: 8
        prefs.useGpu = gpuSw.isChecked
        prefs.targetPackage = pkgEt.text.toString().ifBlank { Prefs.DEFAULT_PACKAGE }
        prefs.listViewId = listIdEt.text.toString()
        prefs.inputViewId = inputIdEt.text.toString()
        prefs.sendButtonId = sendIdEt.text.toString()
        ReplyAccessibilityService.instance?.reloadSettings(reloadModel = gpuChanged)
        toast("保存しました")
    }

    private fun shareDump() {
        val f = File(filesDir, ReplyAccessibilityService.DUMP_FILE)
        if (!f.exists()) { toast("まだ保存されていません"); return }
        // テキストとして共有（メモアプリやメールに送れる）
        val text = f.readText().take(90_000)
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text)
        }, "画面構造を共有"))
    }

    // ---------- UI部品 ----------

    private fun header(s: String, size: Float = 17f) = TextView(this).apply {
        text = s; setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
        setTextColor(Color.parseColor("#4527A0")); setPadding(0, dp(20), 0, dp(6))
        paint.isFakeBoldText = true
    }

    private fun note(s: String) = TextView(this).apply {
        text = s; setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        setTextColor(Color.parseColor("#555555")); setPadding(0, dp(4), 0, dp(4))
    }

    private fun button(s: String, onClick: () -> Unit) = Button(this).apply {
        text = s; isAllCaps = false
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        setOnClickListener { onClick() }
    }

    private fun field(parent: LinearLayout, label: String, value: String, number: Boolean = false, multi: Boolean = false): EditText {
        parent.addView(note(label))
        return EditText(this).apply {
            setText(value)
            inputType = when {
                number -> InputType.TYPE_CLASS_NUMBER
                multi -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
                else -> InputType.TYPE_CLASS_TEXT
            }
            if (multi) { minLines = 2; maxLines = 5 }
            parent.addView(this)
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun mb(b: Long) = "%.0fMB".format(b / 1024.0 / 1024.0)

    companion object { private const val REQ_PICK = 1 }
}
