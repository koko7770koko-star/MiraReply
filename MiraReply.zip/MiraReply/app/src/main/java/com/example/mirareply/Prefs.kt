package com.example.mirareply

import android.content.Context
import java.io.File

/** 設定値（設定画面で変更できる） */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("settings", Context.MODE_PRIVATE)
    private val appContext = context.applicationContext

    /** 対象アプリのパッケージ名（MiraiMind の Android 版） */
    var targetPackage: String
        get() = sp.getString("targetPackage", DEFAULT_PACKAGE) ?: DEFAULT_PACKAGE
        set(v) = sp.edit().putString("targetPackage", v.trim()).apply()

    /** true なら候補1を自動送信する */
    var autoSend: Boolean
        get() = sp.getBoolean("autoSend", false)
        set(v) = sp.edit().putBoolean("autoSend", v).apply()

    /** 自動送信までの待ち秒数（この間に別の候補をタップ／停止できる） */
    var autoSendDelaySec: Int
        get() = sp.getInt("autoSendDelaySec", 5)
        set(v) = sp.edit().putInt("autoSendDelaySec", v.coerceIn(1, 60)).apply()

    /** 返信の雰囲気・自分のキャラ設定など（プロンプトに入る） */
    var styleHint: String
        get() = sp.getString("styleHint", DEFAULT_STYLE) ?: DEFAULT_STYLE
        set(v) = sp.edit().putString("styleHint", v).apply()

    /** AIに読ませる直近メッセージ数 */
    var contextCount: Int
        get() = sp.getInt("contextCount", 8)
        set(v) = sp.edit().putInt("contextCount", v.coerceIn(1, 30)).apply()

    /** GPUを使う（失敗したら自動でCPUに切り替え） */
    var useGpu: Boolean
        get() = sp.getBoolean("useGpu", true)
        set(v) = sp.edit().putBoolean("useGpu", v).apply()

    /** 自動判定がうまくいかない時に手動指定する View ID（例: com.immomo.miraimind:id/et_input） */
    var inputViewId: String
        get() = sp.getString("inputViewId", "") ?: ""
        set(v) = sp.edit().putString("inputViewId", v.trim()).apply()

    var sendButtonId: String
        get() = sp.getString("sendButtonId", "") ?: ""
        set(v) = sp.edit().putString("sendButtonId", v.trim()).apply()

    /** メッセージ一覧の View ID（任意） */
    var listViewId: String
        get() = sp.getString("listViewId", "") ?: ""
        set(v) = sp.edit().putString("listViewId", v.trim()).apply()

    /** 使うモデル（ModelInfo.id） */
    var modelId: String
        get() = sp.getString("modelId", MODELS.first().id) ?: MODELS.first().id
        set(v) = sp.edit().putString("modelId", v).apply()

    val model: ModelInfo get() = MODELS.firstOrNull { it.id == modelId } ?: MODELS.first()

    fun modelFile(m: ModelInfo = model): File =
        File(appContext.getExternalFilesDir(null) ?: appContext.filesDir, m.fileName)

    companion object {
        const val DEFAULT_PACKAGE = "com.immomo.miraimind"
        const val DEFAULT_STYLE = "親しみやすく自然なタメ口。1〜2文くらいの短めの返信。"

        val MODELS = listOf(
            ModelInfo(
                id = "gemma4-e2b",
                label = "Gemma 4 E2B（推奨・約2.6GB・RAM 8GB以上）",
                fileName = "gemma-4-E2B-it.litertlm",
                url = "https://huggingface.co/litert-community/gemma-4-E2B-it-litert-lm/resolve/main/gemma-4-E2B-it.litertlm?download=true",
                sizeBytes = 2_588_147_712L,
            ),
            ModelInfo(
                id = "gemma3-1b",
                label = "Gemma 3 1B（軽量・約0.6GB・RAM 6GB程度でも可、日本語は弱め、要Hugging Faceログイン）",
                fileName = "gemma3-1b-it-int4.litertlm",
                url = "https://huggingface.co/litert-community/Gemma3-1B-IT/resolve/main/gemma3-1b-it-int4.litertlm?download=true",
                sizeBytes = 584_417_280L,
                needsLogin = true,
                pageUrl = "https://huggingface.co/litert-community/Gemma3-1B-IT",
            ),
        )
    }
}

data class ModelInfo(
    val id: String,
    val label: String,
    val fileName: String,
    val url: String,
    val sizeBytes: Long,
    val needsLogin: Boolean = false,
    val pageUrl: String = "",
)
