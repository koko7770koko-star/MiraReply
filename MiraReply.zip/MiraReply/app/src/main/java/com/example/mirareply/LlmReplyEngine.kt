package com.example.mirareply

import android.content.Context
import android.util.Log
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.SamplerConfig
import com.google.ai.edge.litertlm.ThinkingConfig
import java.io.File

/**
 * 端末内で LLM（Gemma）を動かして返信候補を作る。
 * ネットワークには一切アクセスしない。
 * 呼び出しはすべてバックグラウンドスレッドから行うこと（重い処理のため）。
 */
class LlmReplyEngine(private val context: Context) {

    private var engine: Engine? = null
    private var loadedPath: String? = null
    var backendName: String = "-"
        private set

    val isReady: Boolean get() = engine != null

    /** モデルを読み込む（初回は10秒ほどかかる）。読み込み済みなら何もしない。 */
    @Synchronized
    fun ensureLoaded(modelFile: File, useGpu: Boolean) {
        if (engine != null && loadedPath == modelFile.absolutePath) return
        close()
        require(modelFile.exists() && modelFile.length() > 0) {
            "モデルファイルがありません。設定画面からダウンロードしてください。"
        }
        val backends = if (useGpu) listOf<Backend>(Backend.GPU(), Backend.CPU()) else listOf(Backend.CPU())
        var lastError: Throwable? = null
        for (b in backends) {
            try {
                val e = Engine(
                    EngineConfig(
                        modelPath = modelFile.absolutePath,
                        backend = b,
                        maxNumTokens = 4096,
                        cacheDir = context.cacheDir.path,
                    )
                )
                e.initialize()
                engine = e
                loadedPath = modelFile.absolutePath
                backendName = b.name
                Log.i(TAG, "model loaded with ${b.name}")
                return
            } catch (t: Throwable) {
                Log.w(TAG, "backend ${b.name} failed", t)
                lastError = t
            }
        }
        throw IllegalStateException("モデルを読み込めませんでした: ${lastError?.message}", lastError)
    }

    /**
     * 会話履歴から返信候補を3つ作る。
     * @param history 古い順のメッセージ（最後がキャラクターの最新メッセージ）
     */
    @Synchronized
    fun generateReplies(history: List<ChatMessage>, styleHint: String): List<String> {
        val e = engine ?: throw IllegalStateException("モデルが読み込まれていません")

        val system = buildString {
            appendLine("あなたはチャットの返信を考えるアシスタントです。")
            appendLine("ユーザーはAIキャラクターと会話しています。キャラクターの最新メッセージに対して、ユーザーが次に送る返信の候補を3つ作ってください。")
            appendLine("ルール:")
            appendLine("- 3つはそれぞれ方向性を変える（例: 共感・リアクション／質問で話を広げる／ちょっと遊び心）。")
            appendLine("- ユーザー本人の発言として書く。キャラクターのセリフや説明文は書かない。")
            appendLine("- 会話の流れと口調に合わせた自然な日本語にする。")
            appendLine("- 出力は次の形式だけにする。前置きや解説は書かない。")
            appendLine("1. （返信1）")
            appendLine("2. （返信2）")
            appendLine("3. （返信3）")
            if (styleHint.isNotBlank()) {
                appendLine()
                appendLine("ユーザーの希望する返信スタイル: $styleHint")
            }
        }

        val prompt = buildString {
            appendLine("【これまでの会話】")
            for (m in history) {
                val who = if (m.fromUser) "ユーザー" else "キャラクター"
                appendLine("$who: ${m.text.replace('\n', ' ')}")
            }
            appendLine()
            appendLine("【キャラクターの最新メッセージ】")
            appendLine(history.lastOrNull { !it.fromUser }?.text ?: "")
            appendLine()
            append("ユーザーの返信候補を3つ:")
        }

        val conv = createConversation(e, system)
        val raw = try {
            conv.use { it.sendMessage(prompt).toString() }
        } catch (t: Throwable) {
            throw IllegalStateException("返信の生成に失敗しました: ${t.message}", t)
        }
        Log.d(TAG, "raw output:\n$raw")
        return parseCandidates(raw)
    }

    private fun createConversation(e: Engine, system: String): Conversation {
        // 毎回違う候補が出るように seed を変える（「再生成」用）
        val seed = (System.nanoTime() and 0x7fffffff).toInt()
        val sampler = SamplerConfig(topK = 40, topP = 0.95, temperature = 0.9, seed = seed)
        return try {
            e.createConversation(
                ConversationConfig(
                    systemInstruction = Contents.of(system),
                    samplerConfig = sampler,
                    maxOutputToken = 400,
                    // 返信案作りに「考える」時間は不要なのでオフ（速くなる）
                    thinkingConfig = ThinkingConfig(enableThinking = false, thinkingTokenBudget = 0),
                )
            )
        } catch (t: Throwable) {
            // 思考モード非対応モデル向けのフォールバック
            Log.w(TAG, "fallback conversation config", t)
            e.createConversation(
                ConversationConfig(
                    systemInstruction = Contents.of(system),
                    samplerConfig = sampler,
                    maxOutputToken = 400,
                )
            )
        }
    }

    @Synchronized
    fun close() {
        try { engine?.close() } catch (_: Throwable) {}
        engine = null
        loadedPath = null
    }

    companion object {
        private const val TAG = "LlmReplyEngine"

        private val numbered = Regex("""^\s*(?:[1-9１-９][.)．、:：）]|[-・*●])\s*(.+)$""")

        /** モデルの出力から候補文を取り出す */
        fun parseCandidates(raw: String): List<String> {
            val lines = raw.lines().map { it.trim() }.filter { it.isNotEmpty() }
            var items = lines.mapNotNull { numbered.find(it)?.groupValues?.get(1) }
            if (items.isEmpty()) items = lines
            return items
                .map { cleanup(it) }
                .filter { it.isNotEmpty() && !it.startsWith("（返信") }
                .distinct()
                .take(3)
        }

        private fun cleanup(s: String): String {
            var t = s.trim()
            t = t.removePrefix("**").removeSuffix("**").trim()
            // 「ユーザー:」などのラベルを外す
            t = t.replace(Regex("""^(ユーザー|あなた|返信\d?)\s*[:：]\s*"""), "")
            // 全体を囲む括弧・引用符を外す
            val pairs = listOf("「" to "」", "『" to "』", "\"" to "\"", "“" to "”")
            for ((a, b) in pairs) {
                if (t.length >= 2 && t.startsWith(a) && t.endsWith(b)) t = t.substring(a.length, t.length - b.length).trim()
            }
            return t
        }
    }
}
