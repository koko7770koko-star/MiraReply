package com.example.mirareply

import android.accessibilityservice.AccessibilityService
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.Executors

/**
 * MiraiMind の画面を見張り、キャラクターの新しいメッセージが届いたら
 * 端末内AIで返信候補を3つ作ってオーバーレイに出す。
 */
class ReplyAccessibilityService : AccessibilityService(), OverlayPanel.Listener {

    private lateinit var prefs: Prefs
    private lateinit var reader: ChatReader
    private lateinit var overlay: OverlayPanel
    private lateinit var llm: LlmReplyEngine

    private val main = Handler(Looper.getMainLooper())
    // LLM は1本のスレッドで順番に動かす
    private val llmDispatcher = Executors.newSingleThreadExecutor().asCoroutineDispatcher()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private var overlayShown = false
    private var lastHandledKey: String? = null      // 返信案を作り終えた最新メッセージ
    private var generatingKey: String? = null
    private var genJob: Job? = null
    private var genSeq = 0
    private var lastHistory: List<ChatMessage> = emptyList()
    private var candidates: List<String> = emptyList()
    private var countdown: Runnable? = null

    private val scanRunnable = Runnable { scan(force = false) }

    override fun onServiceConnected() {
        super.onServiceConnected()
        prefs = Prefs(this)
        reader = ChatReader(prefs)
        llm = LlmReplyEngine(applicationContext)
        overlay = OverlayPanel(this, this)
        overlay.setAutoSend(prefs.autoSend)
        overlay.setStatus("待機中")
        instance = this
        loadModel()
    }

    private fun loadModel() {
        scope.launch {
            overlay.setStatus("AIモデルを読み込み中…")
            try {
                withContext(llmDispatcher) { llm.ensureLoaded(prefs.modelFile(), prefs.useGpu) }
                overlay.setStatus("準備OK（${llm.backendName}）")
                scan(force = false)
            } catch (t: Throwable) {
                Log.e(TAG, "load failed", t)
                overlay.setStatus(t.message ?: "モデル読み込みエラー")
            }
        }
    }

    /** 設定画面でモデルや設定を変えた時に呼ばれる */
    fun reloadSettings(reloadModel: Boolean) {
        main.post {
            overlay.setAutoSend(prefs.autoSend)
            if (!reloadModel) return@post
            scope.launch {
                withContext(llmDispatcher) { llm.close() }
                loadModel()
            }
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) return // 自分のオーバーレイ由来

        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val active = rootInActiveWindow?.packageName?.toString()
            if (active == prefs.targetPackage) showOverlay() else if (active != null && active != packageName) hideOverlay()
        }
        if (pkg != prefs.targetPackage) return
        showOverlay()
        // キャラの返信は少しずつ表示されることがあるので、変化が落ち着いてから読む
        main.removeCallbacks(scanRunnable)
        main.postDelayed(scanRunnable, SETTLE_MS)
    }

    private fun showOverlay() {
        if (!overlayShown) { overlay.show(); overlayShown = true }
    }

    private fun hideOverlay() {
        if (overlayShown) { overlay.hide(); overlayShown = false }
        cancelCountdown()
    }

    /** 画面を読んで、キャラクターの新着メッセージがあれば返信案を作る */
    private fun scan(force: Boolean) {
        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != prefs.targetPackage) return
        val screen = reader.read(root, resources.displayMetrics.widthPixels)
        val msgs = screen.messages
        if (msgs.isEmpty()) return
        val last = msgs.last()
        if (last.fromUser && !force) return // 最後が自分の発言ならキャラの返事待ち
        val lastChar = msgs.lastOrNull { !it.fromUser } ?: return

        val key = lastChar.text
        if (!force && (key == lastHandledKey || key == generatingKey)) return
        if (!llm.isReady) { overlay.setStatus("AIモデル未読み込み"); return }

        val history = msgs.takeLast(prefs.contextCount)
        generate(key, history)
    }

    private fun generate(key: String, history: List<ChatMessage>) {
        cancelCountdown()
        genJob?.cancel()
        val my = ++genSeq
        generatingKey = key
        lastHistory = history
        overlay.setStatus("返信を考え中…")
        overlay.setCandidates(emptyList())
        overlay.setPanelVisible(true)
        val style = prefs.styleHint
        genJob = scope.launch {
            try {
                val start = System.currentTimeMillis()
                val list = withContext(llmDispatcher) { llm.generateReplies(history, style) }
                val sec = (System.currentTimeMillis() - start) / 100 / 10.0
                if (genSeq != my) return@launch
                candidates = list
                lastHandledKey = key
                overlay.setCandidates(list)
                if (list.isEmpty()) {
                    overlay.setStatus("候補を作れませんでした（再生成を押してください）")
                } else {
                    overlay.setStatus("返信候補（${sec}秒）タップで送信")
                    if (prefs.autoSend) startCountdown()
                }
            } catch (e: CancellationException) {
                throw e
            } catch (t: Throwable) {
                if (genSeq != my) return@launch
                Log.e(TAG, "generate failed", t)
                overlay.setStatus(t.message ?: "生成エラー")
            } finally {
                if (genSeq == my) generatingKey = null
            }
        }
    }

    // ---------- 自動送信 ----------

    private fun startCountdown() {
        cancelCountdown()
        var remain = prefs.autoSendDelaySec
        overlay.setCountdownVisible(true)
        val r = object : Runnable {
            override fun run() {
                if (remain <= 0) {
                    overlay.setCountdownVisible(false)
                    countdown = null
                    candidates.firstOrNull()?.let { sendText(it) }
                    return
                }
                overlay.setStatus("${remain}秒後に 1 を自動送信（別の候補をタップ／停止も可）")
                remain--
                main.postDelayed(this, 1000)
            }
        }
        countdown = r
        main.post(r)
    }

    private fun cancelCountdown() {
        countdown?.let { main.removeCallbacks(it) }
        countdown = null
        if (::overlay.isInitialized) overlay.setCountdownVisible(false)
    }

    // ---------- 入力・送信 ----------

    private fun sendText(text: String) {
        val root = rootInActiveWindow
        if (root == null || root.packageName?.toString() != prefs.targetPackage) {
            toast("MiraiMindの画面が開いていません"); return
        }
        val input = reader.findInput(root)
        if (input == null) {
            toast("入力欄が見つかりません（設定で入力欄IDを指定してください）"); return
        }
        input.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        if (!input.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) {
            toast("入力欄に文字を入れられませんでした"); return
        }
        // 文字が入ると送信ボタンが出るアプリが多いので少し待ってから押す
        main.postDelayed({
            val r2 = rootInActiveWindow ?: return@postDelayed
            val btn = reader.findSendButton(r2, reader.findInput(r2))
            if (btn != null && btn.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                overlay.setStatus("送信しました")
                overlay.setCandidates(emptyList())
                overlay.setPanelVisible(false)
            } else {
                overlay.setStatus("入力欄に入れました。送信ボタンを押してください")
            }
        }, 400)
    }

    // ---------- OverlayPanel.Listener ----------

    override fun onCandidateTapped(index: Int, text: String) {
        cancelCountdown()
        sendText(text)
    }

    override fun onRegenerate() {
        cancelCountdown()
        val root = rootInActiveWindow
        val msgs = if (root != null && root.packageName?.toString() == prefs.targetPackage)
            reader.read(root, resources.displayMetrics.widthPixels).messages else emptyList()
        val history = if (msgs.isNotEmpty()) msgs.takeLast(prefs.contextCount) else lastHistory
        val key = history.lastOrNull { !it.fromUser }?.text
        if (key == null) { overlay.setStatus("キャラクターのメッセージが見つかりません"); return }
        if (!llm.isReady) { overlay.setStatus("AIモデル未読み込み"); return }
        generate(key, history)
    }

    override fun onToggleAutoSend() {
        prefs.autoSend = !prefs.autoSend
        overlay.setAutoSend(prefs.autoSend)
        if (!prefs.autoSend) cancelCountdown()
    }

    override fun onCancelAutoSend() {
        cancelCountdown()
        overlay.setStatus("自動送信を止めました。候補をタップで送信")
    }

    override fun onDumpScreen() {
        val root = rootInActiveWindow ?: return
        val text = buildString {
            appendLine("package=${root.packageName}")
            appendLine("--- 読み取ったメッセージ ---")
            reader.read(root, resources.displayMetrics.widthPixels).messages.forEach {
                appendLine((if (it.fromUser) "[自分] " else "[キャラ] ") + it.text.replace("\n", " "))
            }
            appendLine("--- 画面構造 ---")
            append(ChatReader.dump(root))
        }
        File(filesDir, DUMP_FILE).writeText(text)
        toast("画面構造を保存しました（設定画面から共有できます）")
    }

    private fun toast(s: String) = main.post { Toast.makeText(this, s, Toast.LENGTH_SHORT).show() }

    override fun onInterrupt() {}

    override fun onDestroy() {
        instance = null
        main.removeCallbacksAndMessages(null)
        if (::overlay.isInitialized) hideOverlay()
        scope.cancel()
        if (::llm.isInitialized) {
            val l = llm
            Thread { l.close(); llmDispatcher.close() }.start()
        }
        super.onDestroy()
    }

    companion object {
        private const val TAG = "ReplyService"
        private const val SETTLE_MS = 1500L
        const val DUMP_FILE = "screen_dump.txt"

        @Volatile var instance: ReplyAccessibilityService? = null
    }
}
